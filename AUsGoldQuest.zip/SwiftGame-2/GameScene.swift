import Foundation
import SpriteKit
import AVFoundation
class GameScene: SKScene, SKPhysicsContactDelegate {
    weak var gameViewController: GameViewController?
    var backgroundMusicPlayer: AVAudioPlayer?

    var hero: SKSpriteNode!    
    var heroTexture = SKTexture(imageNamed: "HeroIdleVariant1")
    var heroMovesRight = false
    var heroMovesLeft = false
    var jumpCount = 0
    var looksRight = true
    var looksLeft = false
    var canMoveLeft = true
    var playerwin = false
    var playerDead = false
    var timeSet = false
    var jumpSound: SKAction!
    
    
    var score = 0 {
            didSet {
                gameViewController?.updateScoreLabel(score: score)
            }
        }
        var timeRemaining = 253 {
            didSet {
                gameViewController?.updateTimerLabel(timeRemaining: timeRemaining)
            }
        }
    
    
    enum bitMasks: UInt32 {
        case hero = 0b1
        case ground = 0b10
        case coin = 0b100
    }
    
    enum EnemyBitMasks: UInt32 {
        case frog = 0b1000
        case monkey = 0b10000
        case snail = 0b100000
        case ninja = 0b1000000
        case yeti = 0b10000000
        case snake = 0b100000000
        case droid = 0b1000000000
        case oldRobot = 0b10000000000
        case dozer = 0b100000000000
   


    static func allEnemies() -> [EnemyBitMasks] {
            return [.frog, .monkey, .snail, .ninja, .yeti, .snake, .droid, .oldRobot, .dozer]
        }
       static func combinedBitMask() -> UInt32 {
           var combinedMask: UInt32 = 0
           for enemy in allEnemies() {
               combinedMask |= enemy.rawValue
           }
           return combinedMask
       }
    }
    
    
        lazy var idleTextures: [SKTexture] = loadAnimationTextures(from: "Hero", groupName: "Heroidle")
        lazy var walkTextures: [SKTexture] = loadAnimationTextures(from: "Hero", groupName: "HeroWalk")
        lazy var jumpTextures: [SKTexture] = loadAnimationTextures(from: "Hero", groupName: "HeroJump")
        lazy var dieTextures: [SKTexture] = loadAnimationTextures(from: "Hero", groupName: "HeroDie")

        lazy var idleAction: SKAction = SKAction.repeatForever(SKAction.animate(with: idleTextures, timePerFrame: 0.2))
        lazy var walkAction: SKAction = SKAction.repeatForever(SKAction.animate(with: walkTextures, timePerFrame: 0.1))
        lazy var jumpAction: SKAction = SKAction.animate(with: jumpTextures, timePerFrame: 0.1)
        lazy var dieAction: SKAction = SKAction.animate(with: dieTextures, timePerFrame: 0.1)
        

    // Custom initializer
      init(size: CGSize, gameViewController: GameViewController) {
          self.gameViewController = gameViewController
          super.init(size: size)
          playerwin = false
          timeSet = false
          

          // Your initialization code...
      }

      // Required initializer
      required init?(coder aDecoder: NSCoder) {
          super.init(coder: aDecoder)
          // Perform any additional setup after decoding
      }

    
    override func didMove(to view: SKView) {
        
        self.physicsWorld.contactDelegate = self
        
        // Debug print to check scene initialization
        print("GameScene didMove called")
        
        for node in self.children {
            if node.name == "PhysicsMap" {
                if let someTileMap = node as? SKTileMapNode {
                    tileMapPhysicsBody(map: someTileMap)
                    someTileMap.removeFromParent()
                }
            }
        }
        
        jumpSound = SKAction.playSoundFileNamed("jump.mp3", waitForCompletion: false)

        
        setupAudioSession()

        addHero()
        spawnCoins()
        spawnEnemies()
        startTimer()
        playBackgroundMusic()

        if let cameraNode = camera {
            cameraNode.position.x = hero.position.x + 325 // Adjust as needed
        }
    }
    
    func setupAudioSession() {
            do {
                try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default, options: [.mixWithOthers])
                try AVAudioSession.sharedInstance().setActive(true)
            } catch {
                print("Error setting up audio session: \(error)")
            }
        }
    
    func playBackgroundMusic() {
            if let musicURL = Bundle.main.url(forResource: "ost1", withExtension: "mp3") {
                do {
                    backgroundMusicPlayer = try AVAudioPlayer(contentsOf: musicURL)
                    backgroundMusicPlayer?.numberOfLoops = -1 // Loop indefinitely
                    backgroundMusicPlayer?.play()
                } catch {
                    print("Error loading and playing background music: \(error)")
                }
            }
        }
    
    func addHero() {
        if let heroNode = childNode(withName: "hero") as? SKSpriteNode {
            hero = heroNode
            hero.texture = heroTexture
            let scaledSize = CGSize(width: hero.size.width * 0.7, height: hero.size.height * 0.9)
            hero.physicsBody = SKPhysicsBody(texture: heroTexture, size: scaledSize)
            hero.physicsBody?.allowsRotation = false
            hero.physicsBody?.categoryBitMask = bitMasks.hero.rawValue
            hero.physicsBody?.contactTestBitMask = bitMasks.ground.rawValue | bitMasks.coin.rawValue
            hero.physicsBody?.collisionBitMask = bitMasks.ground.rawValue | EnemyBitMasks.combinedBitMask()
            hero.physicsBody?.affectedByGravity = true
            hero.run(idleAction, withKey: "IdleAction")
        } else {
            print("Hero node not found in the scene.")
        }
    }

    
    func startTimer() {
            let countdownAction = SKAction.repeatForever(SKAction.sequence([
                SKAction.wait(forDuration: 1),
                SKAction.run { [weak self] in
                    self?.updateTimer()
                }
            ]))
            run(countdownAction, withKey: "countdown")
        }

    override func update(_ currentTime: TimeInterval) {
        if timeSet == false{
         if timeRemaining <= 250   {
                gameViewController?.fadeOutIntroImage()
                gameViewController?.resetUI()

             timeSet = true
             
        }
        }
            
            
        if !playerDead {
            if heroMovesRight {
                if hero.action(forKey: "IdleAction") != nil || hero.action(forKey: "JumpAction") != nil {
                    startWalking()
                }
                hero.position.x += 2.5
            } else if heroMovesLeft && canMoveLeft {
                if hero.action(forKey: "IdleAction") != nil || hero.action(forKey: "JumpAction") != nil {
                    startWalking()
                }
                hero.position.x -= 2.5
            } else {
                if hero.action(forKey: "WalkAction") != nil {
                    stopWalking()
                }
            }
            updateCamera()
            
            if hero.position.x > 14720{
                if playerwin == false{
                    playerwin = true
                winLevel()
                }
            }
            
                }
                if hero.position.y < 320 {
                    if playerDead == false{
                        playerDied()}
                }

                
    }
    
    func updateTimer() {
            timeRemaining -= 1
            if timeRemaining <= 0 {
                playerDied()
            }
        }
    
  
    
    func applyJumpImpulse() {
        if jumpCount < 2 {
            startJumping()
            hero.physicsBody?.applyImpulse(CGVector(dx:0, dy: 50 - (jumpCount * 5)))
            
            self.run(jumpSound)
            
            jumpCount += 1
        }
    }
    
    func loadAnimationTextures(from tileSetName: String, groupName: String) -> [SKTexture] {
            guard let tileSet = SKTileSet(named: tileSetName),
                  let tileGroup = tileSet.tileGroups.first(where: { $0.name == groupName }) else {
                print("Tile set or tile group not found")
                return []
            }

            var textures: [SKTexture] = []

            for tile in tileGroup.rules.first?.tileDefinitions ?? [] {
                if let texture = tile.textures.first {
                    textures.append(texture)
               
                }
            }

            return textures
        }
    
    func startWalking() {
            hero.removeAction(forKey: "IdleAction")
            hero.run(walkAction, withKey: "WalkAction")
        }

        func stopWalking() {
            hero.removeAction(forKey: "WalkAction")
            hero.run(idleAction, withKey: "IdleAction")
        }

    func startJumping() {
        hero.removeAction(forKey: "IdleAction")
        hero.removeAction(forKey: "WalkAction")
        hero.run(jumpAction, withKey: "JumpAction")
            let resetAction = SKAction.run {
                    // Reset animation to idle or walk once jump animation completes
                    if self.heroMovesLeft {
                        self.startWalking()
                    } else {
                        self.hero.run(self.idleAction, withKey: "IdleAction")
                    }
                }
                let delay = SKAction.wait(forDuration: jumpAction.duration)
                let sequence = SKAction.sequence([delay, resetAction])
                hero.run(sequence)
    }

        func die() {
            score = 0
            hero.removeAction(forKey: "IdleAction")
            hero.removeAction(forKey: "WalkAction")
            hero.run(dieAction, withKey: "DieAction")
        }
    
    
    func updateCamera() {
        guard let cameraNode = camera else {
            print("No camera")
            return
        }
        
        let screenEdgeMargin: CGFloat = 200 // Adjust as needed
        let cameraMoveSpeed: CGFloat = 2.5// Adjust as needed
        let cameraDamping: CGFloat = 0.2
        
        let leftEdge = cameraNode.position.x - size.width / 2
        let rightEdge = cameraNode.position.x + size.width / 2
        
        var targetXPosition = cameraNode.position.x
        
        if hero.position.x < leftEdge + screenEdgeMargin && hero.position.x > 350 {
            targetXPosition = max(hero.position.x - screenEdgeMargin, cameraNode.position.x - cameraMoveSpeed)
        } else if hero.position.x > rightEdge - screenEdgeMargin - 200 {
            targetXPosition = min(hero.position.x + screenEdgeMargin, cameraNode.position.x + cameraMoveSpeed)
        }
        
        if hero.position.x < leftEdge + hero.frame.width / 2 {
            canMoveLeft = false
        } else {
            canMoveLeft = true
        }
        
        cameraNode.position.x = targetXPosition
        let targetYPosition = hero.position.y + 30
        cameraNode.position.y += (targetYPosition - cameraNode.position.y) * cameraDamping
    }

    func didBegin(_ contact: SKPhysicsContact) {
        let collision = contact.bodyA.categoryBitMask | contact.bodyB.categoryBitMask
        
        if collision == bitMasks.hero.rawValue | bitMasks.ground.rawValue {
            jumpCount = 0
            if hero.action(forKey: "JumpAction") != nil {
                            hero.removeAction(forKey: "JumpAction")
                            hero.run(idleAction, withKey: "IdleAction")
                        }
        }
        
        if collision == bitMasks.hero.rawValue | bitMasks.coin.rawValue {
            collectCoin(contact.bodyA.node, contact.bodyB.node)
        }
        
        if collision & bitMasks.hero.rawValue != 0 {
                // Check if the hero collided with an enemy
                if let enemyNode = contact.bodyA.categoryBitMask == bitMasks.hero.rawValue ? contact.bodyB.node : contact.bodyA.node {
                    handleEnemyCollision(enemyNode)
                }
            }
        
    }
    
    
    func handleEnemyCollision(_ enemyNode: SKNode) {
        // Check if the collided node is an enemy
        guard let enemy = enemyNode as? SKSpriteNode, enemy.name == "Enemy" else {
            return
            
        }
        
        // Retrieve the category bit mask of the collided enemy
        let enemyCategory = enemy.physicsBody?.categoryBitMask ?? 0
        
        // Get the hero's position
        let heroPosition = hero.position
        
        // Handle behavior based on enemy category bit mask
        switch enemyCategory {
        case EnemyBitMasks.frog.rawValue:
            
            // Implement frog-specific behavior
              playerDied() // Example: Player dies when colliding with a frog
        case EnemyBitMasks.monkey.rawValue:
            if heroPosition.y > enemy.position.y {
                // Player hits the snail from above
                enemy.removeFromParent() // Example: Snail disappears when hit from above
            } else {
                playerDied() // Example: Player dies when colliding with a snail from below
            }
        case EnemyBitMasks.snail.rawValue:
            if heroPosition.y > enemy.position.y {
                // Player hits the snail from above
                enemy.removeFromParent() // Example: Snail disappears when hit from above
            } else {
                playerDied() // Example: Player dies when colliding with a snail from below
            }
        case EnemyBitMasks.ninja.rawValue:
            // Implement ninja-specific behavior
            playerDied() // Example: Player dies when colliding with a ninja
        case EnemyBitMasks.yeti.rawValue:
            // Implement yeti-specific behavior
            playerDied() // Example: Player dies when colliding with a yeti
        case EnemyBitMasks.snake.rawValue:
            if heroPosition.y > enemy.position.y {
                // Player hits the snail from above
                enemy.removeFromParent() // Example: Snail disappears when hit from above
            } else {
                playerDied() // Example: Player dies when colliding with a snail from below
            }
        case EnemyBitMasks.droid.rawValue:
            // Implement droid-specific behavior
            playerDied() // Example: Droid disappears when collided with
        case EnemyBitMasks.oldRobot.rawValue:
            // Implement oldRobot-specific behavior
            playerDied() // Example: Old robot disappears when collided with
        case EnemyBitMasks.dozer.rawValue:
            // Implement dozer-specific behavior
            if heroPosition.y > enemy.position.y {
                // Player hits the dozer from above
                enemy.removeFromParent() // Example: Dozer disappears when hit from above
            } else {
                playerDied() // Example: Player dies when colliding with a dozer from below
            }
        default:
            break // Default behavior for unknown enemies
        }
    }


    func collectCoin(_ coinNodeA: SKNode?, _ coinNodeB: SKNode?) {
        guard let coin = coinNodeA?.name == "Coin" ? coinNodeA : coinNodeB?.name == "Coin" ? coinNodeB : nil else { return }
        
        // Stop the animation
        coin.removeAllActions()
        
        // Fade out and remove the coin node
        let fadeOut = SKAction.fadeOut(withDuration: 0.2)
        let remove = SKAction.removeFromParent()
        let sequence = SKAction.sequence([fadeOut, remove])
        coin.run(sequence)
        
        let playSoundAction = SKAction.playSoundFileNamed("coin.mp3", waitForCompletion: false)
        run(playSoundAction)
        
        updateScore(10)
    }
    
    func updateScore(_ points: Int) {
        score += points
        
        if let gameViewController = view?.window?.rootViewController as? GameViewController {
                    gameViewController.updateScoreLabel(score: score)
                }
        
    }
    
    func playerDied() {
        gameViewController?.updateButtonVisibility(isPlayerDead: true)

                playerDead = true
                die()
                backgroundMusicPlayer?.stop()

        let playSoundAction = SKAction.playSoundFileNamed("gameover.mp3", waitForCompletion: false)
        run(playSoundAction)

        DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                // Show death image
                self.gameViewController?.showDeathImage()
            
                
                // Delay before transitioning to the next scene
                let delayAction = SKAction.wait(forDuration: 0.4) // Adjust the delay as needed
            
                let transitionAction = SKAction.run{
                    self.timeRemaining = 250
                    self.restartScene()
                }
                let removeDeathImageAction = SKAction.run {
                    self.gameViewController?.removeDeathImage()
                }
                let sequence = SKAction.sequence([delayAction, removeDeathImageAction, transitionAction])
                self.run(sequence)
    }
    }
    func winLevel(){
        gameViewController?.updateButtonVisibility(isPlayerDead: true)
        backgroundMusicPlayer?.stop()

        GameManager.shared.goToNextLevel()
        
       
  }
        
    
    
    func spawnCoins() {
        guard let coinMap = childNode(withName: "CoinMap") as? SKTileMapNode else {
            print("CoinMap node not found!")
            return
        }

        let coinTextures = [
            SKTexture(imageNamed: "coin1"),
            SKTexture(imageNamed: "coin2")
        ]

        for col in 0..<coinMap.numberOfColumns {
            for row in 0..<coinMap.numberOfRows {
                if let tileDefinition = coinMap.tileDefinition(atColumn: col, row: row) {
                    if tileDefinition.name == "CoinFrame1Variant1" || tileDefinition.name == "CoinFrame1Variant2" {
                        let tileSize = coinMap.tileSize
                        let x = CGFloat(col) * tileSize.width + tileSize.width / 2
                        let y = CGFloat(row) * tileSize.height + tileSize.height / 2

                        // Check if a coin already exists at this position
                        var coinExists = false
                        for child in children {
                            if child.name == "Coin" && child.position == CGPoint(x: x, y: y) {
                                coinExists = true
                                break
                            }
                        }
                        if coinExists { continue } // Skip if a coin already exists at this position

                        let coin = SKSpriteNode(texture: coinTextures[0])
                        coin.position = CGPoint(x: x, y: y)
                        
                        // Define a smaller size for the physics body
                        let physicsBodySize = CGSize(width: coin.size.width * 0.6, height: coin.size.height * 0.6)
                        coin.physicsBody = SKPhysicsBody(rectangleOf: physicsBodySize)
                        
                        coin.physicsBody?.isDynamic = false
                        coin.physicsBody?.categoryBitMask = bitMasks.coin.rawValue
                        coin.physicsBody?.contactTestBitMask = bitMasks.hero.rawValue
                        coin.name = "Coin"

                        let animation = SKAction.repeatForever(SKAction.animate(with: coinTextures, timePerFrame: 0.1))
                        coin.run(animation, withKey: "CoinAnimation") // Set key for the animation

                        addChild(coin)
                    }
                }
            }
        }
    }

    
   
    func spawnEnemies() {
        guard let villainsMap = childNode(withName: "VillainsMap") as? SKTileMapNode else {
            print("VillainsMap node not found!")
            return
        }
        

        print("Spawning enemies...")
        
        for col in 0..<villainsMap.numberOfColumns {
            for row in 0..<villainsMap.numberOfRows {
                if let tileDefinition = villainsMap.tileDefinition(atColumn: col, row: row) {
                    let tileSize = villainsMap.tileSize
                    let x = CGFloat(col) * tileSize.width + tileSize.width / 2
                    let y = CGFloat(row) * tileSize.height + tileSize.height / 2
                    
                    let textureName = tileDefinition.name ?? ""
                    
                    // Check if the tile corresponds to an enemy frame
                    if let enemyType = textureName.components(separatedBy: "Frame").first {
                        let lowercaseEnemyType = enemyType
                                            
                        
                        var enemyTextures: [SKTexture] = []
                            for i in 1 ... determineCategoryBitMask(for: lowercaseEnemyType, returnType: 1) {
                        let textureName = "\(lowercaseEnemyType)Frame1Variant\(i)"
                        let texture = SKTexture(imageNamed: textureName)
                                enemyTextures.append(texture)
                                           }
                        
                        // Create and configure the enemy sprite
                        let enemy = SKSpriteNode(texture: enemyTextures.first)
                        enemy.position = CGPoint(x: x, y: y)
                        let scaledSize = CGSize(width: enemy.size.width * 0.7, height: enemy.size.height * 0.9)
                                            enemy.physicsBody = SKPhysicsBody(rectangleOf: scaledSize)
                        enemy.physicsBody?.isDynamic = false
                        enemy.physicsBody?.affectedByGravity = true
                        enemy.physicsBody?.categoryBitMask = determineCategoryBitMask(for: lowercaseEnemyType, returnType: 0)
                        enemy.physicsBody?.contactTestBitMask = bitMasks.hero.rawValue
                        enemy.physicsBody?.collisionBitMask = bitMasks.hero.rawValue
                        enemy.physicsBody?.friction = 1.0

                        
                        
                        
                        enemy.name = "Enemy"
                        
                        // Animate the enemy
                        let animation = SKAction.repeatForever(SKAction.animate(with: enemyTextures, timePerFrame: 0.1))
                        enemy.run(animation, withKey: "EnemyAnimation")
                        
                        
                        defineMovement(for: enemy, enemyType: lowercaseEnemyType.lowercased())
                        
                        addChild(enemy)
                    }
                }
            }
        }
    }

    func defineMovement(for enemy: SKSpriteNode, enemyType: String) {
        let moveDistance: CGFloat
        let minMoveDuration: TimeInterval
        let maxMoveDuration: TimeInterval
        let shouldJump: Bool

        // Define movement properties based on enemy type
        switch enemyType {
        case "frog":
            moveDistance = 0
            minMoveDuration = 2
            maxMoveDuration = 3.5
            shouldJump = true
            
        case "monkey":
            moveDistance = 60
            minMoveDuration = 0.05
            maxMoveDuration = 0.3
            shouldJump = true
            
        case "snail":
            moveDistance = 200
            minMoveDuration = 4
            maxMoveDuration = 8
            shouldJump = false
            
        case "ninja":
            moveDistance = 250
            minMoveDuration = 0.5
            maxMoveDuration = 1.3
            shouldJump = true
            
        case "yeti":
            moveDistance = 200
            minMoveDuration = 2.0
            maxMoveDuration = 3.0
            shouldJump = false
            
        case "snake":
            moveDistance = 180
            minMoveDuration = 2.0
            maxMoveDuration = 3.0
            shouldJump = false
            
        case "droid":
            moveDistance = 160
            minMoveDuration = 1.5
            maxMoveDuration = 2.5
            shouldJump = true
            
        case "oldrobot":
            moveDistance = 140
            minMoveDuration = 1.5
            maxMoveDuration = 2.5
            shouldJump = false
            
        case "dozer":
            moveDistance = 130
            minMoveDuration = 2.0
            maxMoveDuration = 3.0
            shouldJump = false
            
        default:
            moveDistance = 100
            minMoveDuration = 1.5
            maxMoveDuration = 2.5
            shouldJump = false
        }

        func moveEnemy() {
            if(moveDistance>0 ){
            let moveDuration = TimeInterval.random(in: minMoveDuration...maxMoveDuration)
            let moveRight = SKAction.moveBy(x: moveDistance, y: 0, duration: moveDuration)
            let moveLeft = SKAction.moveBy(x: -moveDistance, y: 0, duration: moveDuration)
            let flipRight = SKAction.run { enemy.xScale = 1 }
            let flipLeft = SKAction.run { enemy.xScale = -1 }
            let moveSequence = SKAction.sequence([moveRight, flipLeft, moveLeft, flipRight, SKAction.run(moveEnemy)])
            enemy.run(moveSequence)
        }
        }
        moveEnemy()
        
        //  startEdgeDetection(for: enemy, moveDistance: moveDistance)

        
        // Add random jump logic if the enemy should jump
        if shouldJump {
            startRandomJumping(for: enemy)
        }
    }

    func startRandomJumping(for enemy: SKSpriteNode) {
        let minJumpInterval: TimeInterval = 2.0
        let maxJumpInterval: TimeInterval = 5.0

        func randomJump() {
            let randomInterval = TimeInterval.random(in: minJumpInterval...maxJumpInterval)
            enemy.run(SKAction.sequence([
                SKAction.wait(forDuration: randomInterval),
                SKAction.run {
                    let jumpHeight: CGFloat = 50 // Adjust the jump height as needed
                    let jumpDuration: TimeInterval = 0.5
                    let jumpUp = SKAction.moveBy(x: 0, y: jumpHeight, duration: jumpDuration / 2)
                    let fallDown = SKAction.moveBy(x: 0, y: -jumpHeight, duration: jumpDuration / 2)
                    let jumpSequence = SKAction.sequence([jumpUp, fallDown])
                    enemy.run(jumpSequence)
                },
                SKAction.run(randomJump) // Recursive call to continue random jumping
            ]))
        }

        randomJump()
    }

 
    
    func determineCategoryBitMask(for enemyType: String, returnType: Int) -> UInt32 {
        switch enemyType {
        case "Frog":
            if(returnType == 0){
                return EnemyBitMasks.frog.rawValue
            }else{
            return 11
        }
        case "Monkey":
            if(returnType == 0){
                return EnemyBitMasks.monkey.rawValue
            }else{
            return 2
        }
           
        case "Snail":
            if(returnType == 0){
                return EnemyBitMasks.snail.rawValue
            }else{
            return 11
        }
           
        case "Ninja":
            if(returnType == 0){
                return EnemyBitMasks.ninja.rawValue
            }else{
            return 8
        }
            
        case "Yeti":
            if(returnType == 0){
                return EnemyBitMasks.yeti.rawValue
            }else{
            return 8
        }
            
        case "Snake":
            if(returnType == 0){
                return EnemyBitMasks.snake.rawValue
            }else{
            return 7
        }
            
        case "Droid":
            if(returnType == 0){
                return EnemyBitMasks.droid.rawValue
            }else{
            return 7
        }
         
        case "OldRobot":
            if(returnType == 0){
                return EnemyBitMasks.oldRobot.rawValue
            }else{
            return 8
        }
           
        case "Dozer":
            if(returnType == 0){
                return EnemyBitMasks.dozer.rawValue
            }else{
            return 8
        }
           
        default:
            return 5 // You can handle the default case according to your needs
        }
    }



    func restartScene() {
        GameManager.shared.resetLevel()
       
    }
    
    func tileMapPhysicsBody(map: SKTileMapNode) {
        let tileMap = map
        let startLocation = tileMap.position
        let tileSize = tileMap.tileSize
        let halfWidth = CGFloat(tileMap.numberOfColumns) / 2.0 * tileSize.width
        let halfHeight = CGFloat(tileMap.numberOfRows) / 2.0 * tileSize.height

        for col in 0..<tileMap.numberOfColumns {
            for row in 0..<tileMap.numberOfRows {
                if let tileDefinition = tileMap.tileDefinition(atColumn: col, row: row) {
                    let tileArray = tileDefinition.textures
                    let tileTexture = tileArray[0]
                    let x = CGFloat(col) * tileSize.width - halfWidth + (tileSize.width / 2)
                    let y = CGFloat(row) * tileSize.height - halfHeight + (tileSize.height / 2)
                    let tileNode = SKSpriteNode(texture: tileTexture)
                    tileNode.position = CGPoint(x: x, y: y)
                    tileNode.physicsBody = SKPhysicsBody(texture: tileTexture, size: tileTexture.size())
                    tileNode.physicsBody?.categoryBitMask = bitMasks.ground.rawValue
                    tileNode.physicsBody?.collisionBitMask = bitMasks.hero.rawValue
                    tileNode.physicsBody?.contactTestBitMask = bitMasks.hero.rawValue
                    tileNode.physicsBody?.affectedByGravity = false
                    tileNode.physicsBody?.isDynamic = false
                    tileNode.physicsBody?.friction = 1.0
                    tileNode.zPosition = 20
                    tileNode.position = CGPoint(x: tileNode.position.x + startLocation.x, y: tileNode.position.y + startLocation.y)
                    self.addChild(tileNode)
                }
            }
        }
    }
}
