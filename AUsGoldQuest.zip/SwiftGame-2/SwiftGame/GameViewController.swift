import UIKit
import SpriteKit

class GameViewController: UIViewController {
    var gameScene: GameScene?
    let skView = SKView()
    var lastJumpTime: TimeInterval = 0

    var leftButton: UIButton!
    var rightButton: UIButton!
    var jumpButton: UIButton!
    
    var scoreLabel: UILabel!
    var timerLabel: UILabel!
    
    var deathImageView = UIImageView(image: UIImage(named: "gameover"))
    var introImageView = UIImageView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        skView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(skView)

        NSLayoutConstraint.activate([
            skView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            skView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            skView.topAnchor.constraint(equalTo: view.topAnchor),
            skView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
        
        skView.ignoresSiblingOrder = true
        skView.showsFPS = true
        skView.showsNodeCount = true
        showIntroImage(for: 0)
        setupLabels()
        setupButtons()
        updateButtonVisibility(isPlayerDead: true)
    }
    
    override var prefersStatusBarHidden: Bool {
           return true
       }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        GameManager.shared.setup(with: self)
    }
    
    func setupLabels() {
        scoreLabel = UILabel()
        scoreLabel.text = "Score: 0"
        scoreLabel.font = UIFont(name: "Arial", size: 24)
        scoreLabel.textColor = .black
        scoreLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scoreLabel)
        
        NSLayoutConstraint.activate([
            scoreLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 15),
            scoreLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 50)
        ])
        
        timerLabel = UILabel()
        timerLabel.text = "Time: 250"
        timerLabel.font = UIFont(name: "Arial", size: 24)
        timerLabel.textColor = .black
        timerLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(timerLabel)
        
        NSLayoutConstraint.activate([
            timerLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 15),
            timerLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -50)
        ])
    }
    
    func updateScoreLabel(score: Int) {
        scoreLabel.text = "Score: \(score)"
    }
    
    func updateTimerLabel(timeRemaining: Int) {
        timerLabel.text = "Time: \(timeRemaining)"
    }

    func setupButtons() {
        let buttonSize = CGSize(width: 70, height: 70)
        leftButton = UIButton()
        rightButton = UIButton()
        jumpButton = UIButton()
                
        leftButton.translatesAutoresizingMaskIntoConstraints = false
        leftButton.setImage(UIImage(named: "left1"), for: .normal)
        leftButton.addTarget(self, action: #selector(leftButtonDown), for: .touchDown)
        leftButton.addTarget(self, action: #selector(leftButtonUp), for: [.touchUpInside, .touchUpOutside])
        view.addSubview(leftButton)
        
        NSLayoutConstraint.activate([
            leftButton.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 50),
            leftButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            leftButton.widthAnchor.constraint(equalToConstant: buttonSize.width),
            leftButton.heightAnchor.constraint(equalToConstant: buttonSize.height)
        ])

        rightButton.translatesAutoresizingMaskIntoConstraints = false
        rightButton.setImage(UIImage(named: "right1"), for: .normal)
        rightButton.addTarget(self, action: #selector(rightButtonDown), for: .touchDown)
        rightButton.addTarget(self, action: #selector(rightButtonUp), for: [.touchUpInside, .touchUpOutside])
        view.addSubview(rightButton)
        
        NSLayoutConstraint.activate([
            rightButton.leadingAnchor.constraint(equalTo: leftButton.trailingAnchor, constant: 50),
            rightButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            rightButton.widthAnchor.constraint(equalToConstant: buttonSize.width),
            rightButton.heightAnchor.constraint(equalToConstant: buttonSize.height)
        ])

        jumpButton.translatesAutoresizingMaskIntoConstraints = false
        jumpButton.setImage(UIImage(named: "jump1"), for: .normal)
        jumpButton.addTarget(self, action: #selector(jumpButtonAction), for: .touchUpInside)
        view.addSubview(jumpButton)
        
        NSLayoutConstraint.activate([
            jumpButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -35),
            jumpButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -20),
            jumpButton.widthAnchor.constraint(equalToConstant: buttonSize.width),
            jumpButton.heightAnchor.constraint(equalToConstant: buttonSize.height)
        ])
    }

    @objc func leftButtonDown() {
        gameScene?.heroMovesLeft = true
        
        if let gameScene = gameScene, gameScene.heroMovesLeft && gameScene.looksRight {
            gameScene.hero.xScale = -gameScene.hero.xScale
            gameScene.looksRight = false
            gameScene.looksLeft = true
        }
    }
    
    @objc func leftButtonUp() {
        gameScene?.heroMovesLeft = false
    }
    
    @objc func rightButtonDown() {
        gameScene?.heroMovesRight = true
        
        if let gameScene = gameScene, gameScene.heroMovesRight && gameScene.looksLeft {
            gameScene.hero.xScale = -gameScene.hero.xScale
            gameScene.looksLeft = false
            gameScene.looksRight = true
        }
    }
    
    @objc func rightButtonUp() {
        gameScene?.heroMovesRight = false
    }
    
    @objc func jumpButtonAction() {
        let currentTime = Date.timeIntervalSinceReferenceDate
        if currentTime - lastJumpTime < 0.4 { // Adjust the cooldown duration as needed
            return // Ignore the jump if within the cooldown period
        }
        lastJumpTime = currentTime
        gameScene?.applyJumpImpulse()
    }
    
    func updateButtonVisibility(isPlayerDead: Bool) {
        let isHidden = isPlayerDead
        leftButton.isHidden = isHidden
        rightButton.isHidden = isHidden
        jumpButton.isHidden = isHidden
        scoreLabel.isHidden = isHidden
        timerLabel.isHidden = isHidden
    }

    func showDeathImage() {
        deathImageView.contentMode = .scaleAspectFit
        deathImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(deathImageView)
        
        NSLayoutConstraint.activate([
            deathImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            deathImageView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 40),
            deathImageView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1),
            deathImageView.heightAnchor.constraint(equalTo: deathImageView.widthAnchor, multiplier: 1.1) // Maintain aspect ratio
        ])
        
        deathImageView.alpha = 0.0
        UIView.animate(withDuration: 0.5) {
            self.deathImageView.alpha = 1.0
        }
    }
    
    func removeDeathImage() {
        deathImageView.removeFromSuperview()
    }

    func resetUI() {
        
        updateButtonVisibility(isPlayerDead: false)
    }
    
 

    func showIntroImage(for levelIndex: Int) {
        let introImageName = "intro\(levelIndex)"
        
        guard let introImage = UIImage(named: introImageName) else { return }
        introImageView = UIImageView(image: introImage)
        introImageView.contentMode = .scaleAspectFit
        introImageView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(introImageView)
        
        NSLayoutConstraint.activate([
            introImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            introImageView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 30),
            introImageView.widthAnchor.constraint(equalTo: view.widthAnchor, multiplier: 1),
            introImageView.heightAnchor.constraint(equalTo: introImageView.widthAnchor, multiplier: 1.5) // Maintain aspect ratio
        ])   }

    func fadeOutIntroImage() {
         let introImageView = introImageView
        
        UIView.animate(withDuration: 0.5, animations: {
            introImageView.alpha = 0.0
        }) { _ in
            introImageView.removeFromSuperview()
        }
    }
    

}


