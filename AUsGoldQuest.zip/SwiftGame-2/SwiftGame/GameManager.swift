import Foundation
import SpriteKit

class GameManager {
    static let shared = GameManager()
    
    private weak var gameViewController: GameViewController?
    public var levelIndex = 0
    public let levelNames = ["LevelOneScene", "LevelTwoScene", "LevelThreeScene"]
    
    private init() {}
    
    func setup(with gameViewController: GameViewController) {
        self.gameViewController = gameViewController
        loadScene(at: levelIndex)
    }
    
    func resetLevel() {
        print("Resetting level...")
        gameViewController?.resetUI()
        loadScene(at: levelIndex)
        
    }
    
    func goToNextLevel() {
        if levelIndex < levelNames.count - 1 {
            levelIndex += 1
            showIntroForCurrentLevel()
            loadScene(at: levelIndex)
            print("Going to next level...")
            
        } else {
            goToMenu()
        }
    }
    
    func goToPreviousLevel() {
        guard levelIndex > 0 else { return }
        levelIndex -= 1
        gameViewController?.resetUI()
        print("Going to previous level...")
       
    }
    
    func goToMenu() {
        // Implement the logic to go to the menu
    }
    
    private func showIntroForCurrentLevel() {
        gameViewController?.showIntroImage(for: levelIndex)
    }
    
    func loadScene(at index: Int) {
        guard let skView = gameViewController?.skView else {
            print("SKView not found")
            return
        }
        let sceneName = levelNames[index]
        print("Loading scene: \(sceneName)")
        
        if let scene = SKScene(fileNamed: sceneName) {
            print("Scene \(sceneName) loaded successfully")
            if let gameScene = scene as? GameScene {
                print("Scene is a GameScene instance")
                gameScene.gameViewController = gameViewController
                gameScene.scaleMode = .aspectFill
                skView.presentScene(gameScene)
                gameViewController?.gameScene = gameScene
                levelIndex = index
            } else {
                print("Loaded scene is not of type GameScene")
            }
        } else {
            print("Failed to load \(sceneName).sks")
        }
    }
}
