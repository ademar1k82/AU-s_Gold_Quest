import UIKit

class MainMenuViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImage(named: "Main")
               let backgroundImageView = UIImageView(image: backgroundImage)
               backgroundImageView.contentMode = .scaleAspectFill
               backgroundImageView.translatesAutoresizingMaskIntoConstraints = false
               view.addSubview(backgroundImageView)
               
               // Set up constraints for background image
               NSLayoutConstraint.activate([
                   backgroundImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: -60), // Adjust the constant value to make the image wider
                   backgroundImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: 60), // Adjust the constant value to make the image wider
                   backgroundImageView.centerYAnchor.constraint(equalTo: view.centerYAnchor, constant: 55),
                   backgroundImageView.heightAnchor.constraint(equalTo: backgroundImageView.widthAnchor, multiplier: 0.1) // Adjust the multiplier to control the height
               ])
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 5.0) {
                   self.startGame()
               }
    
    }
    
    @objc func startGame() {
        let gameViewController = GameViewController()
        if let scene = view.window?.windowScene {
            let window = UIWindow(windowScene: scene)
            window.rootViewController = gameViewController
            window.makeKeyAndVisible()
            // Replace the current window with the new one
            scene.windows.first?.rootViewController?.present(gameViewController, animated: true)
        }
    }
    
    @objc func exitGame() {
        exit(0)
    }
}
