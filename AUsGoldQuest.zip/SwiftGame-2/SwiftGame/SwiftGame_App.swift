import SwiftUI

@main
struct SwiftGame_App: App {
    // Adopting UIApplicationDelegateAdaptor to use AppDelegate
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        WindowGroup {
            MainMenuViewControllerWrapper()
        }
    }
}

struct MainMenuViewControllerWrapper: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> MainMenuViewController {
        return MainMenuViewController()
    }
    
    func updateUIViewController(_ uiViewController: MainMenuViewController, context: Context) {
        // No updates needed for now
    }
}
